interface OnMealClickListener {
    fun onMealClick(meal: Meal)
}
